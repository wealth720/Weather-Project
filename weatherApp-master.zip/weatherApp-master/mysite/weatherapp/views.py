import urllib.request
import json
from django.shortcuts import render
from datetime import datetime, timedelta

def index(request):
    data = {}
    forecast_data = []
    error_message = None
    units = 'metric'  # Default unit is Celsius

    if request.method == 'POST':
        city = request.POST.get('city', '').strip()
        units = request.POST.get('units', 'metric')  # Get the selected units (metric/imperial)

        if city:
            try:
                # Fetching current weather data
                api_key = '3b2703abb8f4f3f05fdd6f04830e0278'
                weather_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&units={units}&appid={api_key}'
                weather_response = urllib.request.urlopen(weather_url).read()
                current_weather = json.loads(weather_response)

                # Fetching 5-day forecast data
                forecast_url = f'http://api.openweathermap.org/data/2.5/forecast?q={city}&units={units}&appid={api_key}'
                forecast_response = urllib.request.urlopen(forecast_url).read()
                forecast_json = json.loads(forecast_response)

                # Extracting current weather data
                data = {
                    "city": city,
                    "country_code": current_weather['sys']['country'],
                    "coordinate": f"{current_weather['coord']['lon']}, {current_weather['coord']['lat']}",
                    "temp": f"{current_weather['main']['temp']} °{'C' if units == 'metric' else 'F'}",
                    "pressure": current_weather['main']['pressure'],
                    "humidity": current_weather['main']['humidity'],
                    "main": current_weather['weather'][0]['main'],
                    "description": current_weather['weather'][0]['description'],
                    "icon": current_weather['weather'][0]['icon'],
                }

                # Extracting 5-day forecast data
                for item in forecast_json['list']:
                    forecast_data.append({
                        "date": datetime.strptime(item['dt_txt'], '%Y-%m-%d %H:%M:%S').strftime('%A, %d %B %Y, %I:%M %p'),
                        "temp": f"{item['main']['temp']} °{'C' if units == 'metric' else 'F'}",
                        "description": item['weather'][0]['description'],
                        "icon": item['weather'][0]['icon'],
                    })

            except urllib.error.URLError as e:
                error_message = "Network error. Please try again later."
            except KeyError:
                error_message = f"City '{city}' not found. Please enter a valid city name."
        else:
            error_message = "Please enter a city name."

    return render(request, "main/index.html", {
        "data": data,
        "forecast_data": forecast_data,
        "error_message": error_message,
        "units": units,
    })
